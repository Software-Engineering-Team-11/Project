How to run code:
-Needed Downloads-
*dotenv
*tkinter
*supabase
*pygubu
*pillow (PIL)
command: pythin main.pygubu

GitHub Cross Reference:
Cali Brewer - crb054
Kristen Babbitt - KristenBabbitt
Rafael Balassiano - Rafaelbala223
Ragael Rasse - rafaelrasse
Logan Deloach - LoganDeLoach
Chase Hudak - ChaseLHudak
Ben Keller - Keller2